from django.shortcuts import render

# Create your views here.

def index(request):
    return render(request,'index.html')

def about(request):
    return render(request,'about.html')

def contact(request):
    return render(request,'contact.html')

def faqs(request):
    return render(request,'faqs.html')

def jobs(request):
    return render(request,'jobs.html')

def news(request):
    return render(request,'news.html')

def videonews(request):
    return render(request,'videonews.html')


